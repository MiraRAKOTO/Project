package mg.douane.intervention.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ReponseController {

}

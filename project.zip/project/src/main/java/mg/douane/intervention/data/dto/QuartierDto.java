package mg.douane.intervention.data.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QuartierDto {
    private long idQuartier;
    private String libelleQuartier;
}

package mg.douane.intervention.data.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PosteDto {
    private Long idPoste;
    private String fonction;
}

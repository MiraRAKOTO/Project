package mg.douane.intervention.data.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategorieDto {
    private Long idCat;
    private String libelleCat;
    private Long idSCat;
}

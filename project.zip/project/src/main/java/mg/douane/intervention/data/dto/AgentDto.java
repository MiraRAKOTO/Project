package mg.douane.intervention.data.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AgentDto {
    private Long idAgent;
    private String numMatAgent;
    private String nomAgent;
    private String prenomAgent;
}
